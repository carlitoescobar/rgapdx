CREATE TABLE `wp_wfScanners` (  `eMin` int(10) unsigned NOT NULL,  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',  `hits` smallint(5) unsigned NOT NULL,  PRIMARY KEY (`eMin`,`IP`)) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `wp_wfScanners` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
INSERT INTO `wp_wfScanners` VALUES('25255860', '\0\0\0\0\0\0\0\0\0\0���FV', '1');
INSERT INTO `wp_wfScanners` VALUES('25255928', '\0\0\0\0\0\0\0\0\0\0��C��', '2');
INSERT INTO `wp_wfScanners` VALUES('25255987', '\0\0\0\0\0\0\0\0\0\0��>)', '1');
INSERT INTO `wp_wfScanners` VALUES('25256003', '\0\0\0\0\0\0\0\0\0\0��Y���', '1');
INSERT INTO `wp_wfScanners` VALUES('25256136', '\0\0\0\0\0\0\0\0\0\0��h�z�', '1');
INSERT INTO `wp_wfScanners` VALUES('25256188', '\0\0\0\0\0\0\0\0\0\0�����v', '1');
INSERT INTO `wp_wfScanners` VALUES('25256240', '\0\0\0\0\0\0\0\0\0\0���^�\\', '1');
INSERT INTO `wp_wfScanners` VALUES('25256775', '\0\0\0\0\0\0\0\0\0\0��Ϛ�a', '1');
INSERT INTO `wp_wfScanners` VALUES('25257152', '\0\0\0\0\0\0\0\0\0\0���,�L', '2');
INSERT INTO `wp_wfScanners` VALUES('25257199', '\0\0\0\0\0\0\0\0\0\0���ط�', '2');
INSERT INTO `wp_wfScanners` VALUES('25257288', '\0\0\0\0\0\0\0\0\0\0��I��', '2');
INSERT INTO `wp_wfScanners` VALUES('25257289', '\0\0\0\0\0\0\0\0\0\0��I��', '5');
INSERT INTO `wp_wfScanners` VALUES('25257487', '\0\0\0\0\0\0\0\0\0\0�����#', '5');
INSERT INTO `wp_wfScanners` VALUES('25257631', '\0\0\0\0\0\0\0\0\0\0��FY��', '2');
INSERT INTO `wp_wfScanners` VALUES('25257660', '\0\0\0\0\0\0\0\0\0\0��G�Fr', '2');
INSERT INTO `wp_wfScanners` VALUES('25257719', '\0\0\0\0\0\0\0\0\0\0��H��', '1');
INSERT INTO `wp_wfScanners` VALUES('25257721', '\0\0\0\0\0\0\0\0\0\0��H��', '1');
INSERT INTO `wp_wfScanners` VALUES('25257786', '\0\0\0\0\0\0\0\0\0\0����K', '1');
INSERT INTO `wp_wfScanners` VALUES('25257839', '\0\0\0\0\0\0\0\0\0\0��y�*�', '1');
INSERT INTO `wp_wfScanners` VALUES('25257872', '\0\0\0\0\0\0\0\0\0\0��G��', '1');
INSERT INTO `wp_wfScanners` VALUES('25257995', '\0\0\0\0\0\0\0\0\0\0��6��', '1');
INSERT INTO `wp_wfScanners` VALUES('25258014', '\0\0\0\0\0\0\0\0\0\0��C��', '5');
INSERT INTO `wp_wfScanners` VALUES('25258153', '\0\0\0\0\0\0\0\0\0\0��	jQ', '1');
INSERT INTO `wp_wfScanners` VALUES('25258417', '\0\0\0\0\0\0\0\0\0\0��6$�\"', '1');
INSERT INTO `wp_wfScanners` VALUES('25258419', '\0\0\0\0\0\0\0\0\0\0���D\'', '1');
INSERT INTO `wp_wfScanners` VALUES('25258663', '\0\0\0\0\0\0\0\0\0\0����9*', '2');
INSERT INTO `wp_wfScanners` VALUES('25258735', '\0\0\0\0\0\0\0\0\0\0���4', '1');
INSERT INTO `wp_wfScanners` VALUES('25258818', '\0\0\0\0\0\0\0\0\0\0��I�֬', '5');
INSERT INTO `wp_wfScanners` VALUES('25258824', '\0\0\0\0\0\0\0\0\0\0��d!��', '2');
/*!40000 ALTER TABLE `wp_wfScanners` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
