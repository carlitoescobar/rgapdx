CREATE TABLE `wp_wfReverseCache` (  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',  `host` varchar(255) NOT NULL,  `lastUpdate` int(10) unsigned NOT NULL,  PRIMARY KEY (`IP`)) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `wp_wfReverseCache` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
INSERT INTO `wp_wfReverseCache` VALUES('\0\0\0\0\0\0\0\0\0\0��B�@', 'crawl-66-249-64-7.googlebot.com', '1517273847');
INSERT INTO `wp_wfReverseCache` VALUES('\0\0\0\0\0\0\0\0\0\0��B�@	', 'crawl-66-249-64-9.googlebot.com', '1517273848');
INSERT INTO `wp_wfReverseCache` VALUES('\0\0\0\0\0\0\0\0\0\0��B�@', 'crawl-66-249-64-11.googlebot.com', '1517270526');
INSERT INTO `wp_wfReverseCache` VALUES('\0\0\0\0\0\0\0\0\0\0��B�@', 'crawl-66-249-64-21.googlebot.com', '1517270411');
INSERT INTO `wp_wfReverseCache` VALUES('\0\0\0\0\0\0\0\0\0\0��B�@', 'crawl-66-249-64-22.googlebot.com', '1517270524');
INSERT INTO `wp_wfReverseCache` VALUES('\0\0\0\0\0\0\0\0\0\0���\0\'�', '198-0-39-197-static.hfc.comcastbusiness.net', '1517264600');
/*!40000 ALTER TABLE `wp_wfReverseCache` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
