CREATE TABLE `wp_wfNet404s` (  `sig` binary(16) NOT NULL,  `ctime` int(10) unsigned NOT NULL,  `URI` varchar(1000) NOT NULL,  PRIMARY KEY (`sig`),  KEY `k1` (`ctime`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_wfNet404s` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
INSERT INTO `wp_wfNet404s` VALUES('J���r��9�i��,�', '1516647551', '/getcfg.php');
INSERT INTO `wp_wfNet404s` VALUES('Z�)�\\��\"�-O[�', '1516647542', '/tmUnblock.cgi');
INSERT INTO `wp_wfNet404s` VALUES('���u�9��~ft��Χ�', '1516647537', '/hndUnblock.cgi');
INSERT INTO `wp_wfNet404s` VALUES('���x)�Ԧ\Z�&Ѿ�', '1516647547', '/moo');
/*!40000 ALTER TABLE `wp_wfNet404s` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
