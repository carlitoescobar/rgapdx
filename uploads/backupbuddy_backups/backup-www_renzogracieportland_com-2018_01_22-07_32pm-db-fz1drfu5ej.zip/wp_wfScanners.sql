CREATE TABLE `wp_wfScanners` (  `eMin` int(10) unsigned NOT NULL,  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',  `hits` smallint(5) unsigned NOT NULL,  PRIMARY KEY (`eMin`,`IP`)) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `wp_wfScanners` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
INSERT INTO `wp_wfScanners` VALUES('25274721', '\0\0\0\0\0\0\0\0\0\0����c', '1');
INSERT INTO `wp_wfScanners` VALUES('25274742', '\0\0\0\0\0\0\0\0\0\0��G��z', '5');
INSERT INTO `wp_wfScanners` VALUES('25274745', '\0\0\0\0\0\0\0\0\0\0��G��z', '2');
INSERT INTO `wp_wfScanners` VALUES('25274753', '\0\0\0\0\0\0\0\0\0\0��#��', '1');
INSERT INTO `wp_wfScanners` VALUES('25274786', '\0\0\0\0\0\0\0\0\0\0��MKO$', '1');
INSERT INTO `wp_wfScanners` VALUES('25274804', '\0\0\0\0\0\0\0\0\0\0��asH�', '2');
INSERT INTO `wp_wfScanners` VALUES('25274975', '\0\0\0\0\0\0\0\0\0\0����%', '1');
INSERT INTO `wp_wfScanners` VALUES('25275136', '\0\0\0\0\0\0\0\0\0\0���.\r�', '1');
INSERT INTO `wp_wfScanners` VALUES('25275214', '\0\0\0\0\0\0\0\0\0\0����B�', '1');
INSERT INTO `wp_wfScanners` VALUES('25275229', '\0\0\0\0\0\0\0\0\0\0���jc', '1');
INSERT INTO `wp_wfScanners` VALUES('25275238', '\0\0\0\0\0\0\0\0\0\0��Y��r', '1');
INSERT INTO `wp_wfScanners` VALUES('25275290', '\0\0\0\0\0\0\0\0\0\0��	p', '1');
INSERT INTO `wp_wfScanners` VALUES('25275620', '\0\0\0\0\0\0\0\0\0\0��6$�', '1');
INSERT INTO `wp_wfScanners` VALUES('25275742', '\0\0\0\0\0\0\0\0\0\0���E\Z�', '3');
INSERT INTO `wp_wfScanners` VALUES('25275873', '\0\0\0\0\0\0\0\0\0\0��Un`', '2');
INSERT INTO `wp_wfScanners` VALUES('25276007', '\0\0\0\0\0\0\0\0\0\0���E�', '1');
INSERT INTO `wp_wfScanners` VALUES('25276137', '\0\0\0\0\0\0\0\0\0\0��G��', '1');
INSERT INTO `wp_wfScanners` VALUES('25276166', '\0\0\0\0\0\0\0\0\0\0���', '2');
INSERT INTO `wp_wfScanners` VALUES('25276487', '\0\0\0\0\0\0\0\0\0\0��Bfk', '2');
INSERT INTO `wp_wfScanners` VALUES('25276487', '\0\0\0\0\0\0\0\0\0\0��Bfm', '2');
INSERT INTO `wp_wfScanners` VALUES('25276494', '\0\0\0\0\0\0\0\0\0\0��<��', '1');
INSERT INTO `wp_wfScanners` VALUES('25276527', '\0\0\0\0\0\0\0\0\0\0����e�', '1');
INSERT INTO `wp_wfScanners` VALUES('25276565', '\0\0\0\0\0\0\0\0\0\0���.\rf', '1');
INSERT INTO `wp_wfScanners` VALUES('25276577', '\0\0\0\0\0\0\0\0\0\0����B�', '1');
INSERT INTO `wp_wfScanners` VALUES('25276626', '\0\0\0\0\0\0\0\0\0\0���z�', '1');
INSERT INTO `wp_wfScanners` VALUES('25276661', '\0\0\0\0\0\0\0\0\0\0��Rv�', '1');
INSERT INTO `wp_wfScanners` VALUES('25276702', '\0\0\0\0\0\0\0\0\0\0����\Z%', '1');
INSERT INTO `wp_wfScanners` VALUES('25276960', '\0\0\0\0\0\0\0\0\0\0���8*', '5');
INSERT INTO `wp_wfScanners` VALUES('25276964', '\0\0\0\0\0\0\0\0\0\0���8*', '1');
INSERT INTO `wp_wfScanners` VALUES('25277070', '\0\0\0\0\0\0\0\0\0\0��h��v', '1');
INSERT INTO `wp_wfScanners` VALUES('25277188', '\0\0\0\0\0\0\0\0\0\0����6�', '2');
INSERT INTO `wp_wfScanners` VALUES('25277189', '\0\0\0\0\0\0\0\0\0\0����6�', '2');
INSERT INTO `wp_wfScanners` VALUES('25277192', '\0\0\0\0\0\0\0\0\0\0����6�', '1');
INSERT INTO `wp_wfScanners` VALUES('25277196', '\0\0\0\0\0\0\0\0\0\0����6�', '2');
INSERT INTO `wp_wfScanners` VALUES('25277197', '\0\0\0\0\0\0\0\0\0\0����6�', '1');
INSERT INTO `wp_wfScanners` VALUES('25277201', '\0\0\0\0\0\0\0\0\0\0����6�', '1');
INSERT INTO `wp_wfScanners` VALUES('25277202', '\0\0\0\0\0\0\0\0\0\0����6�', '1');
INSERT INTO `wp_wfScanners` VALUES('25277206', '\0\0\0\0\0\0\0\0\0\0����6�', '2');
INSERT INTO `wp_wfScanners` VALUES('25277235', '\0\0\0\0\0\0\0\0\0\0��h�m', '1');
INSERT INTO `wp_wfScanners` VALUES('25277250', '\0\0\0\0\0\0\0\0\0\0��(M�A', '1');
INSERT INTO `wp_wfScanners` VALUES('25277389', '\0\0\0\0\0\0\0\0\0\0��B���', '1');
INSERT INTO `wp_wfScanners` VALUES('25277458', '\0\0\0\0\0\0\0\0\0\0���Ja', '1');
INSERT INTO `wp_wfScanners` VALUES('25277459', '\0\0\0\0\0\0\0\0\0\0���Ja', '4');
/*!40000 ALTER TABLE `wp_wfScanners` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
