CREATE TABLE `wp_wfLockedOut` (  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',  `blockedTime` bigint(20) NOT NULL,  `reason` varchar(255) NOT NULL,  `lastAttempt` int(10) unsigned DEFAULT '0',  `blockedHits` int(10) unsigned DEFAULT '0',  PRIMARY KEY (`IP`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_wfLockedOut` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
INSERT INTO `wp_wfLockedOut` VALUES('\0\0\0\0\0\0\0\0\0\0����', '1515771106', 'Used an invalid username \'administrator\' to try to sign in.', '1516034350', '6');
INSERT INTO `wp_wfLockedOut` VALUES('\0\0\0\0\0\0\0\0\0\0��@q ', '1516051853', 'Used an invalid username \'admin\' to try to sign in.', '0', '0');
INSERT INTO `wp_wfLockedOut` VALUES('\0\0\0\0\0\0\0\0\0\0��G��I', '1515816141', 'Used an invalid username \'karynarizumi\' to try to sign in.', '1515906254', '25');
INSERT INTO `wp_wfLockedOut` VALUES('\0\0\0\0\0\0\0\0\0\0��WvtZ', '1516051856', 'Used an invalid username \'admin\' to try to sign in.', '0', '0');
INSERT INTO `wp_wfLockedOut` VALUES('\0\0\0\0\0\0\0\0\0\0��l���', '1515819168', 'Used an invalid username \'admin\' to try to sign in.', '1515819221', '1');
/*!40000 ALTER TABLE `wp_wfLockedOut` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
