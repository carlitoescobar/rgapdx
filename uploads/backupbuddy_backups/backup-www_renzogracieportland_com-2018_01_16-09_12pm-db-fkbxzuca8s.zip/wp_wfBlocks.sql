CREATE TABLE `wp_wfBlocks` (  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',  `blockedTime` bigint(20) NOT NULL,  `reason` varchar(255) NOT NULL,  `lastAttempt` int(10) unsigned DEFAULT '0',  `blockedHits` int(10) unsigned DEFAULT '0',  `wfsn` tinyint(3) unsigned DEFAULT '0',  `permanent` tinyint(3) unsigned DEFAULT '0',  PRIMARY KEY (`IP`),  KEY `k1` (`wfsn`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_wfBlocks` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
INSERT INTO `wp_wfBlocks` VALUES('\0\0\0\0\0\0\0\0\0\0���k�', '1516127832', 'Blocked by Wordfence Security Network', '0', '0', '1', '0');
INSERT INTO `wp_wfBlocks` VALUES('\0\0\0\0\0\0\0\0\0\0��\"�Y�', '1516132787', 'Blocked by Wordfence Security Network', '0', '0', '1', '0');
/*!40000 ALTER TABLE `wp_wfBlocks` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
