CREATE TABLE `wp_wfReverseCache` (  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',  `host` varchar(255) NOT NULL,  `lastUpdate` int(10) unsigned NOT NULL,  PRIMARY KEY (`IP`)) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `wp_wfReverseCache` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
INSERT INTO `wp_wfReverseCache` VALUES('\0\0\0\0\0\0\0\0\0\0��Bfa', 'google-proxy-66-102-6-97.google.com', '1518475305');
INSERT INTO `wp_wfReverseCache` VALUES('\0\0\0\0\0\0\0\0\0\0��Bf|', 'google-proxy-66-102-6-124.google.com', '1518463418');
INSERT INTO `wp_wfReverseCache` VALUES('\0\0\0\0\0\0\0\0\0\0��B�@', 'crawl-66-249-64-7.googlebot.com', '1518504721');
INSERT INTO `wp_wfReverseCache` VALUES('\0\0\0\0\0\0\0\0\0\0��B�@	', 'crawl-66-249-64-9.googlebot.com', '1518501648');
INSERT INTO `wp_wfReverseCache` VALUES('\0\0\0\0\0\0\0\0\0\0��B�@', 'crawl-66-249-64-11.googlebot.com', '1518500423');
INSERT INTO `wp_wfReverseCache` VALUES('\0\0\0\0\0\0\0\0\0\0��B�@', 'crawl-66-249-64-21.googlebot.com', '1518504719');
INSERT INTO `wp_wfReverseCache` VALUES('\0\0\0\0\0\0\0\0\0\0��B�@', 'crawl-66-249-64-22.googlebot.com', '1518548474');
INSERT INTO `wp_wfReverseCache` VALUES('\0\0\0\0\0\0\0\0\0\0��B�@', 'crawl-66-249-64-23.googlebot.com', '1518504720');
INSERT INTO `wp_wfReverseCache` VALUES('\0\0\0\0\0\0\0\0\0\0��B�@V', 'crawl-66-249-64-86.googlebot.com', '1518501647');
INSERT INTO `wp_wfReverseCache` VALUES('\0\0\0\0\0\0\0\0\0\0��B�@X', 'crawl-66-249-64-88.googlebot.com', '1518501646');
INSERT INTO `wp_wfReverseCache` VALUES('\0\0\0\0\0\0\0\0\0\0��B�@Z', 'crawl-66-249-64-90.googlebot.com', '1518534449');
/*!40000 ALTER TABLE `wp_wfReverseCache` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
