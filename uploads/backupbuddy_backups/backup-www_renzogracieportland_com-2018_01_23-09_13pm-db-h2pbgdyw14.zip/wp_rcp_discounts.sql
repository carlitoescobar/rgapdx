CREATE TABLE `wp_rcp_discounts` (  `id` bigint(9) NOT NULL AUTO_INCREMENT,  `name` tinytext NOT NULL,  `description` longtext NOT NULL,  `amount` tinytext NOT NULL,  `unit` tinytext NOT NULL,  `code` tinytext NOT NULL,  `use_count` mediumint(9) NOT NULL,  `max_uses` mediumint(9) NOT NULL,  `status` tinytext NOT NULL,  `expiration` mediumtext NOT NULL,  `subscription_id` mediumint(9) NOT NULL,  PRIMARY KEY (`id`)) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_rcp_discounts` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
INSERT INTO `wp_rcp_discounts` VALUES('1', 'Family Discount', 'One additional discount 20%', '20', '%', 'familydiscount', '0', '0', 'active', '', '0');
/*!40000 ALTER TABLE `wp_rcp_discounts` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
