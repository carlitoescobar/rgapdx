CREATE TABLE `wp_gf_addon_payment_callback` (  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,  `lead_id` int(10) unsigned NOT NULL,  `addon_slug` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL,  `callback_id` varchar(250) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,  `date_created` datetime DEFAULT NULL,  PRIMARY KEY (`id`),  KEY `addon_slug_callback_id` (`addon_slug`(50),`callback_id`(100))) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40000 ALTER TABLE `wp_gf_addon_payment_callback` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
INSERT INTO `wp_gf_addon_payment_callback` VALUES('1', '19', 'gravityformsstripe', 'evt_AVN95d3BXFEJt0', '2017-04-19 17:15:37');
INSERT INTO `wp_gf_addon_payment_callback` VALUES('2', '140', 'gravityformsstripe', 'evt_BTMkGeuwNJPptw', '2017-09-26 20:46:15');
/*!40000 ALTER TABLE `wp_gf_addon_payment_callback` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
