CREATE TABLE `wp_wfReverseCache` (  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',  `host` varchar(255) NOT NULL,  `lastUpdate` int(10) unsigned NOT NULL,  PRIMARY KEY (`IP`)) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `wp_wfReverseCache` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
INSERT INTO `wp_wfReverseCache` VALUES('\0\0\0\0\0\0\0\0\0\0��B�Ev', 'crawl-66-249-69-118.googlebot.com', '1517884225');
INSERT INTO `wp_wfReverseCache` VALUES('\0\0\0\0\0\0\0\0\0\0��B�Ex', 'crawl-66-249-69-120.googlebot.com', '1517884224');
/*!40000 ALTER TABLE `wp_wfReverseCache` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
